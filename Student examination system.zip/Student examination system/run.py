#!/usr/bin/env python3
"""
Student Examination System - Startup Script
Run this file to start the application
"""

import os
import sys
import subprocess

def check_python_version():
    """Check if Python version is 3.7 or higher"""
    if sys.version_info < (3, 7):
        print("Error: Python 3.7 or higher is required.")
        print(f"Current version: {sys.version}")
        sys.exit(1)

def install_requirements():
    """Install required packages"""
    try:
        print("Installing required packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✓ Requirements installed successfully")
    except subprocess.CalledProcessError:
        print("Error: Failed to install requirements")
        print("Please run: pip install -r requirements.txt")
        sys.exit(1)

def main():
    """Main startup function"""
    print("=" * 50)
    print("Student Examination System")
    print("=" * 50)
    
    # Check Python version
    check_python_version()
    print(f"✓ Python version: {sys.version.split()[0]}")
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("Error: requirements.txt not found")
        sys.exit(1)
    
    # Install requirements if needed
    try:
        import flask
        import werkzeug
        print("✓ Required packages already installed")
    except ImportError:
        install_requirements()
    
    # Start the application
    print("\nStarting the application...")
    print("Open your browser and go to: http://localhost:5000")
    print("Default teacher login: admin / admin123")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 50)
    
    try:
        # Import and run the Flask app
        from app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n\nApplication stopped by user")
    except Exception as e:
        print(f"\nError starting application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
