from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime, timedelta
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Database configuration
DATABASE = 'database.db'

def init_db():
    """Initialize the database with required tables"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Teachers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS teachers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Students table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            roll_number TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_approved BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Exams table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            duration_minutes INTEGER DEFAULT 60,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES teachers (id)
        )
    ''')
    
    # Questions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER,
            question_text TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_answer TEXT NOT NULL,
            marks INTEGER DEFAULT 2,
            FOREIGN KEY (exam_id) REFERENCES exams (id)
        )
    ''')
    
    # Results table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            exam_id INTEGER,
            score INTEGER,
            total_marks INTEGER,
            percentage REAL,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (exam_id) REFERENCES exams (id)
        )
    ''')
    
    # Student answers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS student_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            exam_id INTEGER,
            question_id INTEGER,
            selected_answer TEXT,
            is_correct BOOLEAN,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (exam_id) REFERENCES exams (id),
            FOREIGN KEY (question_id) REFERENCES questions (id)
        )
    ''')
    
    # Create default teacher if none exists
    cursor.execute('SELECT COUNT(*) FROM teachers')
    if cursor.fetchone()[0] == 0:
        default_password = generate_password_hash('admin123')
        cursor.execute('INSERT INTO teachers (username, password_hash) VALUES (?, ?)', 
                      ('admin', default_password))
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Routes
@app.route('/')
def home():
    """Homepage with login options"""
    return render_template('home.html')

@app.route('/teacher_login', methods=['GET', 'POST'])
def teacher_login():
    """Teacher login page"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        teacher = conn.execute(
            'SELECT * FROM teachers WHERE username = ?', (username,)
        ).fetchone()
        conn.close()
        
        if teacher and check_password_hash(teacher['password_hash'], password):
            session['teacher_id'] = teacher['id']
            session['teacher_username'] = teacher['username']
            session['user_type'] = 'teacher'
            return redirect(url_for('teacher_dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('teacher_login.html')

@app.route('/teacher_dashboard')
def teacher_dashboard():
    """Teacher dashboard"""
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    
    conn = get_db_connection()
    
    # Get pending student approvals
    pending_students = conn.execute(
        'SELECT * FROM students WHERE is_approved = FALSE ORDER BY created_at DESC'
    ).fetchall()
    
    # Get all students
    all_students = conn.execute(
        'SELECT * FROM students ORDER BY created_at DESC'
    ).fetchall()
    
    # Get exams created by this teacher
    exams = conn.execute(
        'SELECT * FROM exams WHERE created_by = ? ORDER BY created_at DESC',
        (session['teacher_id'],)
    ).fetchall()
    
    # Get exam statistics
    exam_stats = []
    for exam in exams:
        total_students = conn.execute(
            'SELECT COUNT(*) FROM results WHERE exam_id = ?', (exam['id'],)
        ).fetchone()[0]
        avg_score = conn.execute(
            'SELECT AVG(percentage) FROM results WHERE exam_id = ?', (exam['id'],)
        ).fetchone()[0] or 0
        
        exam_stats.append({
            'exam': exam,
            'total_students': total_students,
            'avg_score': round(avg_score, 2)
        })
    
    conn.close()
    
    return render_template('teacher_dashboard.html', 
                         pending_students=pending_students,
                         all_students=all_students,
                         exam_stats=exam_stats)

@app.route('/approve_student/<int:student_id>')
def approve_student(student_id):
    """Approve a student"""
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    
    conn = get_db_connection()
    conn.execute(
        'UPDATE students SET is_approved = TRUE WHERE id = ?', (student_id,)
    )
    conn.commit()
    conn.close()
    
    flash('Student approved successfully', 'success')
    return redirect(url_for('teacher_dashboard'))

@app.route('/create_exam', methods=['GET', 'POST'])
def create_exam():
    """Create a new exam"""
    if 'teacher_id' not in session:
        return redirect(url_for('teacher_login'))
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        duration = int(request.form['duration'])
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO exams (title, description, duration_minutes, created_by) VALUES (?, ?, ?, ?)',
            (title, description, duration, session['teacher_id'])
        )
        exam_id = cursor.lastrowid
        
        # Add questions
        questions_data = request.form.getlist('questions[]')
        for i, question_data in enumerate(questions_data):
            if question_data.strip():
                parts = question_data.split('|')
                if len(parts) >= 6:
                    question_text = parts[0]
                    option_a = parts[1]
                    option_b = parts[2]
                    option_c = parts[3]
                    option_d = parts[4]
                    correct_answer = parts[5]
                    
                    cursor.execute(
                        'INSERT INTO questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)',
                        (exam_id, question_text, option_a, option_b, option_c, option_d, correct_answer)
                    )
        
        conn.commit()
        conn.close()
        
        flash('Exam created successfully', 'success')
        return redirect(url_for('teacher_dashboard'))
    
    return render_template('create_exam.html')

@app.route('/student_register', methods=['GET', 'POST'])
def student_register():
    """Student registration"""
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        roll_number = request.form['roll_number']
        password = request.form['password']
        
        # Check if email or roll number already exists
        conn = get_db_connection()
        existing_student = conn.execute(
            'SELECT * FROM students WHERE email = ? OR roll_number = ?',
            (email, roll_number)
        ).fetchone()
        
        if existing_student:
            flash('Email or roll number already exists', 'error')
            conn.close()
            return render_template('student_register.html')
        
        # Create new student
        password_hash = generate_password_hash(password)
        conn.execute(
            'INSERT INTO students (name, email, roll_number, password_hash) VALUES (?, ?, ?, ?)',
            (name, email, roll_number, password_hash)
        )
        conn.commit()
        conn.close()
        
        flash('Registration successful! Please wait for teacher approval.', 'success')
        return redirect(url_for('student_login'))
    
    return render_template('student_register.html')

@app.route('/student_login', methods=['GET', 'POST'])
def student_login():
    """Student login"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        student = conn.execute(
            'SELECT * FROM students WHERE email = ?', (email,)
        ).fetchone()
        conn.close()
        
        if student and check_password_hash(student['password_hash'], password):
            if student['is_approved']:
                session['student_id'] = student['id']
                session['student_name'] = student['name']
                session['student_email'] = student['email']
                session['user_type'] = 'student'
                return redirect(url_for('student_dashboard'))
            else:
                flash('Your account is pending teacher approval', 'warning')
        else:
            flash('Invalid email or password', 'error')
    
    return render_template('student_login.html')

@app.route('/student_dashboard')
def student_dashboard():
    """Student dashboard"""
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    
    conn = get_db_connection()
    
    # Get available exams
    exams = conn.execute(
        'SELECT * FROM exams ORDER BY created_at DESC'
    ).fetchall()
    
    # Get student's exam history
    exam_history = conn.execute(
        '''SELECT e.title, r.score, r.total_marks, r.percentage, r.submitted_at
           FROM results r
           JOIN exams e ON r.exam_id = e.id
           WHERE r.student_id = ?
           ORDER BY r.submitted_at DESC''',
        (session['student_id'],)
    ).fetchall()
    
    conn.close()
    
    return render_template('student_dashboard.html', 
                         exams=exams, 
                         exam_history=exam_history)

@app.route('/exam/<int:exam_id>')
def exam(exam_id):
    """Take an exam"""
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    
    conn = get_db_connection()
    
    # Check if student already took this exam
    existing_result = conn.execute(
        'SELECT * FROM results WHERE student_id = ? AND exam_id = ?',
        (session['student_id'], exam_id)
    ).fetchone()
    
    if existing_result:
        flash('You have already taken this exam', 'warning')
        conn.close()
        return redirect(url_for('student_dashboard'))
    
    # Get exam details and questions
    exam = conn.execute(
        'SELECT * FROM exams WHERE id = ?', (exam_id,)
    ).fetchone()
    
    questions = conn.execute(
        'SELECT * FROM questions WHERE exam_id = ? ORDER BY id', (exam_id,)
    ).fetchall()
    
    conn.close()
    
    if not exam or not questions:
        flash('Exam not found or no questions available', 'error')
        return redirect(url_for('student_dashboard'))
    
    return render_template('exam.html', exam=exam, questions=questions)

@app.route('/submit_exam', methods=['POST'])
def submit_exam():
    """Submit exam answers"""
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    
    exam_id = int(request.form['exam_id'])
    answers = request.form.to_dict()
    
    conn = get_db_connection()
    
    # Get exam questions
    questions = conn.execute(
        'SELECT * FROM questions WHERE exam_id = ?', (exam_id,)
    ).fetchall()
    
    score = 0
    total_marks = 0
    
    # Calculate score
    for question in questions:
        total_marks += question['marks']
        question_id = question['id']
        selected_answer = answers.get(f'question_{question_id}')
        
        if selected_answer == question['correct_answer']:
            score += question['marks']
        
        # Store student answer
        conn.execute(
            'INSERT INTO student_answers (student_id, exam_id, question_id, selected_answer, is_correct) VALUES (?, ?, ?, ?, ?)',
            (session['student_id'], exam_id, question_id, selected_answer, selected_answer == question['correct_answer'])
        )
    
    percentage = (score / total_marks * 100) if total_marks > 0 else 0
    
    # Store result
    conn.execute(
        'INSERT INTO results (student_id, exam_id, score, total_marks, percentage) VALUES (?, ?, ?, ?, ?)',
        (session['student_id'], exam_id, score, total_marks, percentage)
    )
    
    conn.commit()
    conn.close()
    
    return redirect(url_for('exam_result', exam_id=exam_id))

@app.route('/exam_result/<int:exam_id>')
def exam_result(exam_id):
    """Display exam result"""
    if 'student_id' not in session:
        return redirect(url_for('student_login'))
    
    conn = get_db_connection()
    
    # Get result details
    result = conn.execute(
        '''SELECT r.*, e.title as exam_title
           FROM results r
           JOIN exams e ON r.exam_id = e.id
           WHERE r.student_id = ? AND r.exam_id = ?''',
        (session['student_id'], exam_id)
    ).fetchone()
    
    # Get question details with answers
    questions_with_answers = conn.execute(
        '''SELECT q.*, sa.selected_answer, sa.is_correct
           FROM questions q
           LEFT JOIN student_answers sa ON q.id = sa.question_id AND sa.student_id = ?
           WHERE q.exam_id = ?
           ORDER BY q.id''',
        (session['student_id'], exam_id)
    ).fetchall()
    
    conn.close()
    
    if not result:
        flash('Result not found', 'error')
        return redirect(url_for('student_dashboard'))
    
    return render_template('exam_result.html', result=result, questions=questions_with_answers)

@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('home'))

@app.route('/exit')
def exit_app():
    """Exit application"""
    return redirect(url_for('home'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
