# Student Examination System

A comprehensive web-based examination system built with Flask, featuring secure authentication, exam creation, and real-time exam taking capabilities.

## Features

### For Teachers
- **Secure Login**: Password hashing and session management
- **Student Approval**: Review and approve student registrations
- **Exam Creation**: Create multiple-choice exams with customizable duration
- **Performance Analytics**: View student performance and exam statistics
- **Dashboard**: Comprehensive overview of all system activities

### For Students
- **Registration**: Simple registration process with email verification
- **Secure Login**: Login only after teacher approval
- **Exam Taking**: Interactive exam interface with timer
- **Real-time Progress**: Track answered questions and remaining time
- **Result Review**: Detailed exam results with question-by-question analysis
- **Performance History**: View past exam results and performance trends

### System Features
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Modern UI**: Built with Bootstrap 5 and custom CSS
- **Real-time Timer**: Automatic exam submission when time expires
- **Progress Tracking**: Visual progress indicators during exams
- **Accessibility**: Keyboard navigation and screen reader support
- **Security**: Password hashing, session management, and input validation

## Installation

### Prerequisites
- Python 3.7 or higher
- pip (Python package installer)

### Setup Instructions

1. **Clone or Download** the project files to your local machine

2. **Navigate** to the project directory:
   ```bash
   cd "Student examination system"
   ```

3. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the Application**:
   ```bash
   python app.py
   ```

5. **Access the Application**:
   Open your web browser and go to `http://localhost:5000`

## Default Login Credentials

### Teacher Login
- **Username**: `admin`
- **Password**: `admin123`

## Usage Guide

### Getting Started

1. **Homepage**: The application opens with three main options:
   - Teacher Login
   - Student Login
   - Student Registration

### For Teachers

1. **Login**: Use the default credentials or create a new teacher account
2. **Student Approval**: 
   - View pending student registrations
   - Approve students to allow exam access
3. **Create Exam**:
   - Click "Create Exam" from the dashboard
   - Enter exam title, description, and duration
   - Add multiple-choice questions with options A, B, C, D
   - Specify the correct answer for each question
   - Save the exam
4. **View Analytics**: Monitor student performance and exam statistics

### For Students

1. **Registration**:
   - Click "Student Registration" from homepage
   - Fill in name, email, roll number, and password
   - Wait for teacher approval
2. **Login**: Use email and password after approval
3. **Take Exams**:
   - Select an available exam from dashboard
   - Read instructions and start the exam
   - Answer questions by clicking on options
   - Monitor progress and remaining time
   - Submit when finished or time expires
4. **View Results**: Review detailed exam results and performance

## Project Structure

```
Student examination system/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── database.db           # SQLite database (created automatically)
├── templates/            # HTML templates
│   ├── base.html         # Base template with navigation
│   ├── home.html         # Homepage
│   ├── teacher_login.html
│   ├── teacher_dashboard.html
│   ├── create_exam.html
│   ├── student_login.html
│   ├── student_register.html
│   ├── student_dashboard.html
│   ├── exam.html         # Exam taking interface
│   └── exam_result.html  # Exam results
└── static/               # Static files
    ├── style.css         # Custom CSS
    └── script.js         # Custom JavaScript
```

## Database Schema

The system uses SQLite with the following tables:

- **teachers**: Teacher accounts and credentials
- **students**: Student accounts, approval status
- **exams**: Exam information and settings
- **questions**: Individual questions with options
- **results**: Student exam scores and performance
- **student_answers**: Individual question responses

## Security Features

- **Password Hashing**: Uses Werkzeug's secure password hashing
- **Session Management**: Secure session handling with Flask sessions
- **Input Validation**: Server-side validation for all inputs
- **SQL Injection Protection**: Uses parameterized queries
- **XSS Protection**: Jinja2 template escaping

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (responsive design)

## Troubleshooting

### Common Issues

1. **Port Already in Use**:
   - Change the port in `app.py`: `app.run(debug=True, port=5001)`

2. **Database Errors**:
   - Delete `database.db` and restart the application to recreate the database

3. **CSS/JS Not Loading**:
   - Check that the `static/` folder exists and contains the files
   - Clear browser cache

4. **Permission Errors**:
   - Run with administrator privileges if needed
   - Check file permissions in the project directory

### Getting Help

If you encounter issues:
1. Check the console output for error messages
2. Verify all dependencies are installed correctly
3. Ensure Python version is 3.7 or higher
4. Check that all files are in the correct directories

## Future Enhancements

Potential improvements for the system:
- Email notifications for approvals and results
- Advanced question types (essay, true/false)
- Bulk question import from CSV/Excel
- Advanced analytics and reporting
- Mobile app version
- Integration with Learning Management Systems
- Automated grading for essay questions
- Question banks and randomization

## License

This project is open source and available under the MIT License.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.
